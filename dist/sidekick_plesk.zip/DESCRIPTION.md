Do you learn through interaction and task completion? Then meet SIDEKICK - you’ll become fast friends. Think of having an FAQ section spring to life as a real-time expert, available 24/7. This extension adds the SIDEKICK platform to your Plesk installation, with up to 180 interactive walkthroughs.

# Introducing SIDEKICK

[![Introducing SIDEKICK](http://img.youtube.com/vi/ag7MGwP8cbg/0.jpg)](https://www.youtube.com/watch?v=ag7MGwP8cbg)

You and your users will learn how to solve your own issues and perform any tasks on any platform. No documentation, no videos, no support desks. Just you and your SIDEKICK.

# SIDEKICK Pro for WordPress

[![Introducing SIDEKICK](http://img.youtube.com/vi/SlPCOrgse3c/0.jpg)](https://www.youtube.com/watch?v=SlPCOrgse3c)

This has got to be the most convenient, cost-effective way to provide training and support. If you want a complete list of available tutorials and more information on SIDEKICK you can [see it all here](http://www.sidekick.pro/plesk-extension).
